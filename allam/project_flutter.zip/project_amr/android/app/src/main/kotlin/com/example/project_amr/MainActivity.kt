package com.example.project_amr

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
